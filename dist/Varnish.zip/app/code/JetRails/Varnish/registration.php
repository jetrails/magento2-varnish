<?php

	use Magento\Framework\Component\ComponentRegistrar;

	ComponentRegistrar::register ( ComponentRegistrar::MODULE, "JetRails_Varnish", __DIR__ );